package com.ohgiraffers.secondbackend.user.entity;

public enum UserRole {
    USER, ADMIN
}
