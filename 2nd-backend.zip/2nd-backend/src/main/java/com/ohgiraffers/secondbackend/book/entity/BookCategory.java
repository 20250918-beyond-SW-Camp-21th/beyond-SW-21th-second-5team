package com.ohgiraffers.secondbackend.book.entity;

public enum BookCategory {
    FICTION, NONFICTION, NOVEL, MYSTERY, SF, FANTASY,
    ROMANCE, HORROR, SCIENCEFICTION, HISTORY, CHILDREN,
    YA,PICTURE_BOOK
}
