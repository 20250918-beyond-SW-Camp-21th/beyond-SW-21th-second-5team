package com.ohgiraffers.secondbackend.readingclubreview.dto.request;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class ReadingClubReviewRequestDTO {

    private String reviewTitle;
    private String reviewContent;
}
