package com.ohgiraffers.secondbackend.readingclub.entity;

public enum JoinRequestStatus {
    PENDING, APPROVED, REJECTED
}
