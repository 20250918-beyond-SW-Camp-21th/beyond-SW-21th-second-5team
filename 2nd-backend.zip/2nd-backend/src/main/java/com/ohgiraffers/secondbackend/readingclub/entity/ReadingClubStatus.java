package com.ohgiraffers.secondbackend.readingclub.entity;

public enum ReadingClubStatus {
    OPEN,           // 모집 중
    CLOSED,         // 모집 마감
    FINISHED        // 종료
}
