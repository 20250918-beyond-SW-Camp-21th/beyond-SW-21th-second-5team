package com.ohgiraffers.secondbackend.readingclub.entity;

public enum ReadingClubMemberRole {
    HOST, MEMBER, LEFT
}
